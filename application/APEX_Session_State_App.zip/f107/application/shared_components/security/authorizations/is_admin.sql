prompt --application/shared_components/security/authorizations/is_admin
begin
--   Manifest
--     SECURITY SCHEME: Is_Admin
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_security_scheme(
 p_id=>wwv_flow_api.id(2022332918962479)
,p_name=>'Is_Admin'
,p_scheme_type=>'NATIVE_ITEM_EQUALS_VALUE'
,p_attribute_01=>'F_ROLE'
,p_attribute_02=>'ADMIN'
,p_error_message=>unistr('Nur f\00FCr Rolle "Admin"')
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_api.component_end;
end;
/
