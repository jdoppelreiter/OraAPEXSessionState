prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(1969123265969110)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Home'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'JOERG'
,p_last_upd_yyyymmddhh24miss=>'20211122131505'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1983317929087813)
,p_plug_name=>'Details'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1879546099969039)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_column=>6
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1983997982087819)
,p_plug_name=>unistr('Aktivit\00E4ten')
,p_parent_plug_id=>wwv_flow_api.id(1983317929087813)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1859958368969029)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ca.id,',
'       ca.name,',
'       case ',
'            when length(ca.description)  > 100',
'                then substr(ca.description,0,100) || ''...''',
'            else ca.description ',
'        end as description,',
'       ca.link,',
'       cai.image,',
'       cai.mime_type,',
'       a.image as logo,',
'       case ',
'            when ca.active_yn = ''Y'' ',
'                then ''fa-check-circle-o''',
'            else ''fa-circle-o''',
'        end as active_img,',
'        case ',
'            when ca.active_yn = ''Y'' ',
'                then ''Inaktiv setzen''',
'            else ''Aktiv setzen''',
'        end as active_button_text,',
'        case ',
'            when ca.active_yn = ''Y'' ',
'                then ''act-active''',
'            else ''act-inactive''',
'        end as status_css_class',
'  from country_activities ca',
'  join activities a on ca.act_id = a.id',
'  left join country_activity_images cai on cai.cny_act_id = ca.id and cai.thumbnail_yn=''Y''',
'  where ca.iso_code = :P1_CNY ',
'    and ca.act_id   = nvl(:P1_ACTIVITIES,ca.act_id)',
'    and ( ',
'            has_authorization_yn( p_authorization_name => ''Is_Admin'' ) = ''Y''',
'            or',
'            ca.active_yn = ''Y''',
'        )',
'  '))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P1_CNY,P1_ACTIVITIES'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_api.create_card(
 p_id=>wwv_flow_api.id(1984003023087820)
,p_region_id=>wwv_flow_api.id(1983997982087819)
,p_layout_type=>'GRID'
,p_card_css_classes=>'&STATUS_CSS_CLASS.'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'DESCRIPTION'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'BLOB'
,p_icon_blob_column_name=>'LOGO'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'ID'
);
wwv_flow_api.create_card_action(
 p_id=>wwv_flow_api.id(1984373146087823)
,p_card_id=>wwv_flow_api.id(1984003023087820)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&LINK.'
,p_link_attributes=>'target="_blank"'
);
wwv_flow_api.create_card_action(
 p_id=>wwv_flow_api.id(1985427980087834)
,p_card_id=>wwv_flow_api.id(1984003023087820)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>40
,p_label=>'Modal'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:20:P20_ID:&ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-edit'
,p_is_hot=>true
,p_authorization_scheme=>wwv_flow_api.id(2022332918962479)
);
wwv_flow_api.create_card_action(
 p_id=>wwv_flow_api.id(5001841072294506)
,p_card_id=>wwv_flow_api.id(1984003023087820)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>60
,p_label=>'Redirect'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::P15_ID:&ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-edit'
,p_is_hot=>true
,p_authorization_scheme=>wwv_flow_api.id(2022332918962479)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1991859871206226)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1848772294969023)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'COUNTRY_ACTIVITIES'
,p_include_rowid_column=>false
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_ajax_items_to_submit=>'P100_CNY,P100_ACTIVITIES'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_map_region(
 p_id=>wwv_flow_api.id(1993832998206229)
,p_region_id=>wwv_flow_api.id(1991859871206226)
,p_height=>640
,p_tilelayer_type=>'CUSTOM'
,p_tilelayer_name_default=>'world-map'
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_init_position_from_browser=>true
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'MOUSEWHEEL_ZOOM:RECTANGLE_ZOOM:SCALE_BAR:INFINITE_MAP:BROWSER_LOCATION'
);
wwv_flow_api.create_map_region_layer(
 p_id=>wwv_flow_api.id(1994351659206232)
,p_map_region_id=>wwv_flow_api.id(1993832998206229)
,p_name=>'Klettersteig'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_row_assignment_column=>'ACT_ID'
,p_row_assignment_value=>'1'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_api.create_map_region_layer(
 p_id=>wwv_flow_api.id(1983893434087818)
,p_map_region_id=>wwv_flow_api.id(1993832998206229)
,p_name=>'Go-Kart'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_row_assignment_column=>'ACT_ID'
,p_row_assignment_value=>'2'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_api.create_map_region_layer(
 p_id=>wwv_flow_api.id(1986483520087844)
,p_map_region_id=>wwv_flow_api.id(1993832998206229)
,p_name=>'Langlaufen'
,p_layer_type=>'POINT'
,p_display_sequence=>30
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_row_assignment_column=>'ACT_ID'
,p_row_assignment_value=>'3'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(10596457926214862)
,p_name=>unistr('Aktivit\00E4tenliste')
,p_template=>wwv_flow_api.id(1859958368969029)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--noBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.name as Land',
unistr('     , a.name as Aktivit\00E4t'),
'     , ca.name',
'     , substr(ca.description,0,70)||''...'' as Beschreibung',
'     , ca.link',
'     , ca.active_yn as Aktiv',
'     , cap_d.value as Schwierigkeit',
'     , cap_m.value as Mindestalter',
'  from country_activities ca',
'  join countries c on ca.iso_code = c.iso_code',
'  join activities a on ca.act_id = a.id',
'  left join country_activity_parameters cap_d on ca.id = cap_d.ca_id and cap_d.param = ''DIFFICULTY''',
'  left join country_activity_parameters cap_m on ca.id = cap_m.ca_id and cap_m.param = ''MINIMUM_AGE''',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(1907049990969059)
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5338967555254568)
,p_query_column_id=>1
,p_column_alias=>'LAND'
,p_column_display_sequence=>10
,p_column_heading=>'Land'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5339320481254568)
,p_query_column_id=>2
,p_column_alias=>unistr('AKTIVIT\00C4T')
,p_column_display_sequence=>20
,p_column_heading=>unistr('Aktivit\00E4t')
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5339788904254568)
,p_query_column_id=>3
,p_column_alias=>'NAME'
,p_column_display_sequence=>30
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5340181768254570)
,p_query_column_id=>4
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>40
,p_column_heading=>'Beschreibung'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5340521137254570)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5340980544254570)
,p_query_column_id=>6
,p_column_alias=>'AKTIV'
,p_column_display_sequence=>60
,p_column_heading=>'Aktiv'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5341332468254570)
,p_query_column_id=>7
,p_column_alias=>'SCHWIERIGKEIT'
,p_column_display_sequence=>70
,p_column_heading=>'Schwierigkeit'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5341792490254570)
,p_query_column_id=>8
,p_column_alias=>'MINDESTALTER'
,p_column_display_sequence=>80
,p_column_heading=>'Mindestalter'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5354548706617462)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10596457926214862)
,p_button_name=>'RESET'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_image_alt=>unistr('Zusatzinfos zur\00FCcksetzen')
,p_button_position=>'REGION_TEMPLATE_COPY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1985685314087836)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1983997982087819)
,p_button_name=>'ADD_ACTIVITY'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(1944782162969082)
,p_button_image_alt=>unistr('Neue Aktivit\00E4t anlegen')
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:20::'
,p_icon_css_classes=>'fa-asterisk'
,p_security_scheme=>wwv_flow_api.id(2022332918962479)
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1982445078087804)
,p_name=>'P1_LAT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(1991859871206226)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1982526406087805)
,p_name=>'P1_LNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(1991859871206226)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1983599554087815)
,p_name=>'P1_CNY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(1983317929087813)
,p_prompt=>unistr('L\00E4nderauswahl')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name, iso_code ',
'  from countries',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_icon_css_classes=>'fa-globe'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1983735636087817)
,p_name=>'P1_ACTIVITIES'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(1983317929087813)
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.name  --||''(''||a.id||'')''',
'     , a.id',
'  from activities a'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Alle'
,p_lov_cascade_parent_items=>'P1_CNY'
,p_ajax_items_to_submit=>'P1_CNY'
,p_ajax_optimize_refresh=>'Y'
,p_field_template=>wwv_flow_api.id(1942038966969079)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--radioButtonGroup'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'99'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1985056433087830)
,p_name=>'P1_STATUS_CHANGE_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(1983317929087813)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1982637347087806)
,p_name=>'Map Changed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(1991859871206226)
,p_bind_type=>'bind'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapclick'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1982790461087807)
,p_event_id=>wwv_flow_api.id(1982637347087806)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_LAT'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.lat'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1982873922087808)
,p_event_id=>wwv_flow_api.id(1982637347087806)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_LNG'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.lng'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1982903989087809)
,p_event_id=>wwv_flow_api.id(1982637347087806)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_country;',
'let v_url = ''http://api.geonames.org/countryCode?lat=''+this.data.lat+''&lng=''+this.data.lng+''&username=jdoppelreiter''',
'console.log(''call api: ''+v_url);',
'$.ajax({',
'        url: v_url',
'    }).then(function(data) {',
'       $s(''P1_CNY'',data.trim());',
'    });'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1984128766087821)
,p_name=>'onChange: Activities'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_ACTIVITIES'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1984209678087822)
,p_event_id=>wwv_flow_api.id(1984128766087821)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(1983997982087819)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1984814606087828)
,p_name=>'Event - Change Status'
,p_event_sequence=>30
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'ChangeStatus'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1984973539087829)
,p_event_id=>wwv_flow_api.id(1984814606087828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_STATUS_CHANGE_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1985183343087831)
,p_event_id=>wwv_flow_api.id(1984814606087828)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update country_activities set active_yn = decode(active_yn,''Y'',''N'',''Y'') ',
'  where id = :P1_STATUS_CHANGE_ID;'))
,p_attribute_02=>'P1_STATUS_CHANGE_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1985225347087832)
,p_event_id=>wwv_flow_api.id(1984814606087828)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(1983997982087819)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(2084743933736004)
,p_name=>'Close Dialog'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(1983317929087813)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2084893192736005)
,p_event_id=>wwv_flow_api.id(2084743933736004)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(1983997982087819)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5005246284294540)
,p_event_id=>wwv_flow_api.id(2084743933736004)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(10596457926214862)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5354864622618537)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset'
,p_process_sql_clob=>'delete from country_activity_parameters;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5354548706617462)
);
wwv_flow_api.component_end;
end;
/
