prompt --application/pages/page_00060
begin
--   Manifest
--     PAGE: 00060
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_page(
 p_id=>60
,p_user_interface_id=>wwv_flow_api.id(1969123265969110)
,p_name=>'Database Queries'
,p_alias=>'DATABASE-QUERIES'
,p_step_title=>'Database Queries'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'JOERG'
,p_last_upd_yyyymmddhh24miss=>'20211122131232'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5358849396894927)
,p_plug_name=>'Verwendung von V/NV'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1859958368969029)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5358968465894928)
,p_plug_name=>'Query (V/NV)'
,p_parent_plug_id=>wwv_flow_api.id(5358849396894927)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_api.id(1844857615969017)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from user_source where regexp_like(text,''n?v\(''''P[0-9]+'',''i'');',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5359033591894929)
,p_plug_name=>'Report (V/NV)'
,p_parent_plug_id=>wwv_flow_api.id(5358849396894927)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1877686696969037)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from user_source where regexp_like(text,''n?v\(''''P[0-9]+'',''i'');',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Report (V/NV)'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5359157158894930)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF:RTF:EMAIL'
,p_owner=>'JOERG'
,p_internal_uid=>5359157158894930
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5359287399894931)
,p_db_column_name=>'NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5359364911894932)
,p_db_column_name=>'TYPE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5359421373894933)
,p_db_column_name=>'LINE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Line'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5359570312894934)
,p_db_column_name=>'TEXT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Text'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5359696010894935)
,p_db_column_name=>'ORIGIN_CON_ID'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Origin Con Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7246206069381837)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'72463'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NAME:TYPE:LINE:TEXT:ORIGIN_CON_ID'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5359723238894936)
,p_plug_name=>'Items to Submit'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1859958368969029)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5360090430894939)
,p_plug_name=>'Query (Items to Submit)'
,p_parent_plug_id=>wwv_flow_api.id(5359723238894936)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_api.id(1844857615969017)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  distinct ',
'        rs.application_id',
'      , rs.page_id',
'      , rs.region_name',
'      , rs.element as region_source_item',
'      , ai.element as ajax_items_to_submit',
'      , to_char(rs.region_source) as region_source',
'from ',
' (',
' SELECT  v.application_id',
'        ,v.page_id',
'        ,v.region_name',
'        ,to_char(REGEXP_SUBSTR(string, ''P[0-9]+_[_A-Z]+'',1,LEVEL,''i'')) AS element',
'        ,region_source',
'      FROM (select region_source as string,a.* from apex_application_page_regions a where application_id = :APP_ID and query_type_code = ''SQL'' and regexp_like(region_source,'':P[0-9]+_[_A-Z]+'',''i'')) v',
'      CONNECT BY LEVEL <= REGEXP_COUNT(string, ''P[0-9]+_[_A-Z]+'',1,''i'')',
') rs',
' left join   ',
' (SELECT  v.application_id',
'        ,v.page_id',
'        ,v.region_name',
'        ,to_char(REGEXP_SUBSTR(string, ''P[0-9]+_[_A-Z]+'',1,LEVEL,''i'')) AS element',
'        ,region_source',
'      FROM (select ajax_items_to_submit as string,a.* from apex_application_page_regions a where application_id = :APP_ID and query_type_code = ''SQL'' and ajax_items_to_submit is not null) v',
'      CONNECT BY LEVEL <= REGEXP_COUNT(string, ''P[0-9]+_[_A-Z]+'',1,''i'')',
'  ) ai',
'    on rs.application_id = ai.application_id',
'    and rs.page_id = ai.page_id',
'    and rs.region_name = ai.region_name',
'    and rs.element = ai.element',
'  where ai.element is null',
'  order by application_id, page_id, region_name'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7253016845425507)
,p_plug_name=>'Report'
,p_parent_plug_id=>wwv_flow_api.id(5359723238894936)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1877686696969037)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  distinct ',
'        rs.application_id',
'      , rs.page_id',
'      , rs.region_name',
'      , rs.element as region_source_item',
'      , ai.element as ajax_items_to_submit',
'      , to_char(rs.region_source) as region_source',
'from ',
' (',
' SELECT  v.application_id',
'        ,v.page_id',
'        ,v.region_name',
'        ,to_char(REGEXP_SUBSTR(string, ''P[0-9]+_[_A-Z]+'',1,LEVEL,''i'')) AS element',
'        ,region_source',
'      FROM (select region_source as string,a.* from apex_application_page_regions a ',
'      where application_id = :APP_ID and query_type_code = ''SQL'' ',
'      and regexp_like(region_source,'':P[0-9]+_[_A-Z]+'',''i'')) v',
'      CONNECT BY LEVEL <= REGEXP_COUNT(string, ''P[0-9]+_[_A-Z]+'',1,''i'')',
') rs',
' left join   ',
' (SELECT  v.application_id',
'        ,v.page_id',
'        ,v.region_name',
'        ,to_char(REGEXP_SUBSTR(string, ''P[0-9]+_[_A-Z]+'',1,LEVEL,''i'')) AS element',
'        ,region_source',
'      FROM (select ajax_items_to_submit as string,a.* ',
'      from apex_application_page_regions a ',
'      where application_id = :APP_ID and query_type_code = ''SQL'' and ajax_items_to_submit is not null) v',
'      CONNECT BY LEVEL <= REGEXP_COUNT(string, ''P[0-9]+_[_A-Z]+'',1,''i'')',
'  ) ai',
'    on rs.application_id = ai.application_id',
'    and rs.page_id = ai.page_id',
'    and rs.region_name = ai.region_name',
'    and rs.element = ai.element',
'  where ai.element is null',
'  order by application_id, page_id, region_name'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Report'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7253127867425508)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF:RTF:EMAIL'
,p_owner=>'JOERG'
,p_internal_uid=>7253127867425508
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7253326228425510)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7253428815425511)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7253557807425512)
,p_db_column_name=>'REGION_NAME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Region Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7253697943425513)
,p_db_column_name=>'REGION_SOURCE_ITEM'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Region Source Item'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7253781251425514)
,p_db_column_name=>'AJAX_ITEMS_TO_SUBMIT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Ajax Items To Submit'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7253843805425515)
,p_db_column_name=>'REGION_SOURCE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Region Source'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7271238971435779)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'72713'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'APPLICATION_ID:PAGE_ID:REGION_NAME:REGION_SOURCE_ITEM:REGION_SOURCE:'
);
wwv_flow_api.component_end;
end;
/
