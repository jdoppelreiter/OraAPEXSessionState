prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_page(
 p_id=>100
,p_user_interface_id=>wwv_flow_api.id(1969123265969110)
,p_name=>'Home: "Submit - Refresh"'
,p_alias=>'HOME-SUBMIT-REFRESH'
,p_step_title=>'Home: "Submit - Refresh"'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'JOERG'
,p_last_upd_yyyymmddhh24miss=>'20211122131514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6959848550328088)
,p_plug_name=>'Details'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1879546099969039)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_column=>6
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6960528603328094)
,p_plug_name=>unistr('Aktivit\00E4ten')
,p_parent_plug_id=>wwv_flow_api.id(6959848550328088)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1859958368969029)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ca.id,',
'       ca.name,',
'       case ',
'            when length(ca.description)  > 100',
'                then substr(ca.description,0,100) || ''...''',
'            else ca.description ',
'        end as description,',
'       ca.link,',
'       cai.image,',
'       cai.mime_type,',
'       a.image as logo,',
'       case ',
'            when ca.active_yn = ''Y'' ',
'                then ''fa-check-circle-o''',
'            else ''fa-circle-o''',
'        end as active_img,',
'        case ',
'            when ca.active_yn = ''Y'' ',
'                then ''Inaktiv setzen''',
'            else ''Aktiv setzen''',
'        end as active_button_text,',
'        case ',
'            when ca.active_yn = ''Y'' ',
'                then ''act-active''',
'            else ''act-inactive''',
'        end as status_css_class',
'  from country_activities ca',
'  join activities a on ca.act_id = a.id',
'  left join country_activity_images cai on cai.cny_act_id = ca.id and cai.thumbnail_yn=''Y''',
'  where ca.iso_code = :P100_CNY ',
'    and ca.act_id   = nvl(:P100_ACTIVITIES,ca.act_id)',
'    and ( ',
'            has_authorization_yn( p_authorization_name => ''Is_Admin'' ) = ''Y''',
'            or',
'            ca.active_yn = ''Y''',
'        )'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P100_CNY ,P100_ACTIVITIES'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_api.create_card(
 p_id=>wwv_flow_api.id(4979099440240295)
,p_region_id=>wwv_flow_api.id(6960528603328094)
,p_layout_type=>'GRID'
,p_card_css_classes=>'&STATUS_CSS_CLASS.'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'DESCRIPTION'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'BLOB'
,p_icon_blob_column_name=>'LOGO'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'ID'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6968390492446501)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1848772294969023)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'COUNTRY_ACTIVITIES'
,p_include_rowid_column=>false
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_map_region(
 p_id=>wwv_flow_api.id(4983655442240301)
,p_region_id=>wwv_flow_api.id(6968390492446501)
,p_height=>640
,p_tilelayer_type=>'CUSTOM'
,p_tilelayer_name_default=>'world-map'
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_init_position_from_browser=>true
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'MOUSEWHEEL_ZOOM:RECTANGLE_ZOOM:SCALE_BAR:INFINITE_MAP:BROWSER_LOCATION'
);
wwv_flow_api.create_map_region_layer(
 p_id=>wwv_flow_api.id(4984175363240303)
,p_map_region_id=>wwv_flow_api.id(4983655442240301)
,p_name=>'Klettersteig'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_row_assignment_column=>'ACT_ID'
,p_row_assignment_value=>'1'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_api.create_map_region_layer(
 p_id=>wwv_flow_api.id(4984706761240303)
,p_map_region_id=>wwv_flow_api.id(4983655442240301)
,p_name=>'Go-Kart'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_row_assignment_column=>'ACT_ID'
,p_row_assignment_value=>'2'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_api.create_map_region_layer(
 p_id=>wwv_flow_api.id(4985394365240304)
,p_map_region_id=>wwv_flow_api.id(4983655442240301)
,p_name=>'Langlaufen'
,p_layer_type=>'POINT'
,p_display_sequence=>30
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_row_assignment_column=>'ACT_ID'
,p_row_assignment_value=>'3'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8151915300510849)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(6960528603328094)
,p_button_name=>'Aktualisieren'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_image_alt=>'Aktualisieren'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4982905278240300)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(6960528603328094)
,p_button_name=>'ADD_ACTIVITY'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(1944782162969082)
,p_button_image_alt=>unistr('Neue Aktivit\00E4t anlegen')
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15::'
,p_icon_css_classes=>'fa-asterisk'
,p_security_scheme=>wwv_flow_api.id(2022332918962479)
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7291902394223502)
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::P100_CNY,P100_ACTIVITIES:&P100_CNY.,&P100_ACTIVITIES.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4977570629240287)
,p_name=>'P100_CNY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(6959848550328088)
,p_prompt=>unistr('L\00E4nderauswahl')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name, iso_code ',
'  from countries',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4977910582240290)
,p_name=>'P100_ACTIVITIES'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(6959848550328088)
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.name, a.id',
'  from activities a'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Alle'
,p_field_template=>wwv_flow_api.id(1942038966969079)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--radioButtonGroup'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'99'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4978313931240290)
,p_name=>'P100_STATUS_CHANGE_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(6959848550328088)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4985951441240304)
,p_name=>'P100_LAT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6968390492446501)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4986334203240304)
,p_name=>'P100_LNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(6968390492446501)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(4986706557240309)
,p_name=>'Map Changed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(6968390492446501)
,p_bind_type=>'bind'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapclick'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(4987294285240310)
,p_event_id=>wwv_flow_api.id(4986706557240309)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P100_LAT'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.lat'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(4987792889240312)
,p_event_id=>wwv_flow_api.id(4986706557240309)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P100_LNG'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.lng'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(4988206098240312)
,p_event_id=>wwv_flow_api.id(4986706557240309)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_country;',
'let v_url = ''http://api.geonames.org/countryCode?lat=''+this.data.lat+''&lng=''+this.data.lng+''&username=jdoppelreiter''',
'console.log(''call api: ''+v_url);',
'$.ajax({',
'        url: v_url',
'    }).then(function(data) {',
'       $s(''P100_CNY'',data.trim());',
'    });'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(4989526593240314)
,p_name=>'Event - Change Status'
,p_event_sequence=>30
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'ChangeStatus'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(4990049996240314)
,p_event_id=>wwv_flow_api.id(4989526593240314)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P100_STATUS_CHANGE_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(4990513353240315)
,p_event_id=>wwv_flow_api.id(4989526593240314)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update country_activities set active_yn = decode(active_yn,''Y'',''N'',''Y'') ',
'  where id = :P100_STATUS_CHANGE_ID;'))
,p_attribute_02=>'P100_STATUS_CHANGE_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(4991068008240315)
,p_event_id=>wwv_flow_api.id(4989526593240314)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(6960528603328094)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(4991440085240315)
,p_name=>'Close Dialog'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(6959848550328088)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(4991993289240315)
,p_event_id=>wwv_flow_api.id(4991440085240315)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(6960528603328094)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(2089001036736047)
,p_name=>'OnChange: Activity'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_ACTIVITIES'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2089135559736048)
,p_event_id=>wwv_flow_api.id(2089001036736047)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8152057775510850)
,p_name=>'Refresh'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(8151915300510849)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9221172159303501)
,p_event_id=>wwv_flow_api.id(8152057775510850)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(6960528603328094)
);
wwv_flow_api.component_end;
end;
/
