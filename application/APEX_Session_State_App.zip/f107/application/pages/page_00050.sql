prompt --application/pages/page_00050
begin
--   Manifest
--     PAGE: 00050
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_page(
 p_id=>50
,p_user_interface_id=>wwv_flow_api.id(1969123265969110)
,p_name=>'Session Test-Page'
,p_alias=>'SESSION-TEST-PAGE'
,p_step_title=>'Session Test-Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'JOERG'
,p_last_upd_yyyymmddhh24miss=>'20211007182642'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5001912336294507)
,p_plug_name=>'Current Session'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1879546099969039)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5004211801294530)
,p_plug_name=>'Clone Session'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1879546099969039)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<a href="&P50_CLONE_URL." target="_blank">&P50_CLONE_URL.</a>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5002243140294510)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5001912336294507)
,p_button_name=>'Submit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit Page'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5002094720294508)
,p_name=>'P50_SESSION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5001912336294507)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Session Id'
,p_source=>':APP_SESSION'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5003829698294526)
,p_name=>'P50_CLONE_URL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5004211801294530)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_page.get_url(p_application => ''oracle-apex-session-state''',
'                , p_page    => ''session-test-page''',
'                , p_session => :APP_SESSION',
'                , p_request => ''APEX_CLONE_SESSION'')'))
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
