prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_page(
 p_id=>15
,p_user_interface_id=>wwv_flow_api.id(1969123265969110)
,p_name=>unistr('Aktivit\00E4t Details (Branch)')
,p_alias=>unistr('AKTIVIT\00C4T-DETAILS-BRANCH')
,p_step_title=>unistr('Aktivit\00E4t Details (Branch)')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'JOERG'
,p_last_upd_yyyymmddhh24miss=>'20211116161510'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7054026778383810)
,p_plug_name=>unistr('Aktivit\00E4t')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1879546099969039)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8151376494510843)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(7054026778383810)
,p_button_name=>'UPDATE_ACTIVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_image_alt=>'Update Active'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5009445769935903)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7054026778383810)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5009861690935903)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7054026778383810)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P15_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5010290787935903)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7054026778383810)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_condition=>'P15_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5010680889935904)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(7054026778383810)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_condition=>'P15_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5018278357935910)
,p_branch_name=>'Go To Page 1'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8151179179510841)
,p_branch_name=>'Go To Page 15'
,p_branch_action=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::P15_ID:&P15_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>11
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5011001029935904)
,p_name=>'P15_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7054026778383810)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5011466564935904)
,p_name=>'P15_ISO_CODE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(7054026778383810)
,p_prompt=>'Iso Code'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select name, iso_code from countries'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(1943444924969081)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5011820313935904)
,p_name=>'P15_ACT_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7054026778383810)
,p_prompt=>unistr('Aktivit\00E4t')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select name, id from activities'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5012264139935904)
,p_name=>'P15_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(7054026778383810)
,p_prompt=>'Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>200
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5012679583935906)
,p_name=>'P15_DESCRIPTION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(7054026778383810)
,p_prompt=>'Description'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>10
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5013002278935906)
,p_name=>'P15_LATITUDE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(7054026778383810)
,p_prompt=>'Latitude'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5013467681935906)
,p_name=>'P15_LONGITUDE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(7054026778383810)
,p_prompt=>'Longitude'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5013813851935906)
,p_name=>'P15_LINK'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(7054026778383810)
,p_prompt=>'Link'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>400
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5014226611935906)
,p_name=>'P15_ACTIVE_YN'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(7054026778383810)
,p_prompt=>'Aktiv'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8151453615510844)
,p_name=>'Update Active'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(8151376494510843)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8151584238510845)
,p_event_id=>wwv_flow_api.id(8151453615510844)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'update_active(:P15_ID);'
,p_attribute_02=>'P15_ID,P15_ACTIVE_YN'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5017740042935910)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P15_ID is null then',
'  :P15_ID := seq_cny_act_id.nextval;',
'  insert ',
'    into country_activities',
'     ( id',
'     , iso_code',
'     , act_id',
'     , name',
'     , description',
'     , latitude',
'     , longitude',
'     , link',
'     , active_yn)',
'    values ',
'     ( :P15_ID',
'     , :P15_ISO_CODE',
'     , :P15_ACT_ID',
'     , :P15_NAME',
'     , :P15_DESCRIPTION',
'     , :P15_LATITUDE',
'     , :P15_LONGITUDE',
'     , :P15_LINK',
'     , :P15_ACTIVE_YN);',
'else',
'  update country_activities',
'     set  iso_code    = :P15_ISO_CODE',
'        , act_id      = :P15_ACT_ID',
'        , name        = :P15_NAME',
'        , description = :P15_DESCRIPTION',
'        , latitude    = :P15_LATITUDE',
'        , longitude   = :P15_LONGITUDE',
'        , link        = :P15_LINK',
'        , active_yn   = :P15_ACTIVE_YN ',
'    where id = :P15_ID;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5001670150294504)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Data'
,p_process_sql_clob=>'delete from country_activities where id = :P15_ID;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5009861690935903)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5017303416935909)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select iso_code',
'     , act_id',
'     , name',
'     , description',
'     , latitude',
'     , longitude',
'     , link',
'     , active_yn',
'  into :P15_ISO_CODE',
'     , :P15_ACT_ID',
'     , :P15_NAME',
'     , :P15_DESCRIPTION',
'     , :P15_LATITUDE',
'     , :P15_LONGITUDE',
'     , :P15_LINK',
'     , :P15_ACTIVE_YN',
'  from country_activities ',
'  where id = :P15_ID; '))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P15_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.component_end;
end;
/
