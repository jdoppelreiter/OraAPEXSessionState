prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_page(
 p_id=>20
,p_user_interface_id=>wwv_flow_api.id(1969123265969110)
,p_name=>unistr('Aktivit\00E4t Details (Modal Page)')
,p_alias=>unistr('AKTIVIT\00C4T-DETAILS-MODAL-PAGE')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Aktivit\00E4t')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'JOERG'
,p_last_upd_yyyymmddhh24miss=>'20211116162012'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1985565037087835)
,p_plug_name=>'Actions'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1849500155969023)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2086267407736019)
,p_plug_name=>'Zusatzangaben'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:is-collapsed:t-Region--noBorder:t-Region--scrollBody:margin-top-none'
,p_plug_template=>wwv_flow_api.id(1859958368969029)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2086318234736020)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1879546099969039)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4105196464032520)
,p_plug_name=>unistr('Aktivit\00E4t')
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1879546099969039)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'COUNTRY_ACTIVITIES'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2060912604584612)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1985565037087835)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P20_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2060526824584610)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(1985565037087835)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2061371904584612)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(1985565037087835)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P20_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2061794054584612)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(1985565037087835)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P20_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2062130490584615)
,p_name=>'P20_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4105196464032520)
,p_item_source_plug_id=>wwv_flow_api.id(4105196464032520)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2062511533584617)
,p_name=>'P20_ISO_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4105196464032520)
,p_item_source_plug_id=>wwv_flow_api.id(4105196464032520)
,p_prompt=>'Land'
,p_source=>'ISO_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select name, iso_code from countries'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(1943444924969081)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2062909128584617)
,p_name=>'P20_ACT_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(4105196464032520)
,p_item_source_plug_id=>wwv_flow_api.id(4105196464032520)
,p_prompt=>unistr('Aktivit\00E4t')
,p_source=>'ACT_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select name, id from activities'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2063371338584617)
,p_name=>'P20_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(4105196464032520)
,p_item_source_plug_id=>wwv_flow_api.id(4105196464032520)
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>200
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2063738813584618)
,p_name=>'P20_DESCRIPTION'
,p_source_data_type=>'CLOB'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(4105196464032520)
,p_item_source_plug_id=>wwv_flow_api.id(4105196464032520)
,p_prompt=>'Beschreibung'
,p_source=>'DESCRIPTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>6
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2064193138584618)
,p_name=>'P20_LATITUDE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(4105196464032520)
,p_item_source_plug_id=>wwv_flow_api.id(4105196464032520)
,p_prompt=>'Latitude'
,p_source=>'LATITUDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2064523679584618)
,p_name=>'P20_LONGITUDE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(4105196464032520)
,p_item_source_plug_id=>wwv_flow_api.id(4105196464032520)
,p_prompt=>'Longitude'
,p_source=>'LONGITUDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2064919328584618)
,p_name=>'P20_LINK'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(4105196464032520)
,p_item_source_plug_id=>wwv_flow_api.id(4105196464032520)
,p_prompt=>'Link'
,p_source=>'LINK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>400
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2065378912584618)
,p_name=>'P20_ACTIVE_YN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(1985565037087835)
,p_item_source_plug_id=>wwv_flow_api.id(4105196464032520)
,p_prompt=>'Aktiv'
,p_source=>'ACTIVE_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2086558941736022)
,p_name=>'P20_MINIMUM_AGE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(2086267407736019)
,p_prompt=>'Mindestalter'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2086868198736025)
,p_name=>'P20_DIFFICULTY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(2086267407736019)
,p_prompt=>'Schwierigkeit'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(1942172730969079)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(1986566144087845)
,p_computation_sequence=>10
,p_computation_item=>'P20_NAME'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'Dachstein Gletscher'
,p_compute_when=>'P20_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(1986698257087846)
,p_computation_sequence=>20
,p_computation_item=>'P20_DESCRIPTION'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>unistr('Skigebiet mit Pisten, Loipen, Eispalast und Plattformen, die spektakul\00E4re Ausblicke bieten.')
,p_compute_when=>'P20_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(1986164619087841)
,p_computation_sequence=>30
,p_computation_item=>'P20_LATITUDE'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'47.45130812001816'
,p_compute_when=>'P20_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(1986212554087842)
,p_computation_sequence=>40
,p_computation_item=>'P20_LONGITUDE'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'13.618078827485437'
,p_compute_when=>'P20_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(1986868121087848)
,p_computation_sequence=>50
,p_computation_item=>'P20_LINK'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'https://www.derdachstein.at/de'
,p_compute_when=>'P20_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(1987077670087850)
,p_computation_sequence=>60
,p_computation_item=>'P20_ACTIVE_YN'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'Y'
,p_compute_when=>'P20_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(1986094877087840)
,p_computation_sequence=>70
,p_computation_item=>'P20_ACT_ID'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'P1_ACTIVITIES'
,p_compute_when=>'P20_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(1985865267087838)
,p_computation_sequence=>80
,p_computation_item=>'P20_ISO_CODE'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'P1_CNY'
,p_compute_when=>'P20_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(2084493487736001)
,p_computation_sequence=>90
,p_computation_item=>'P20_ID'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'seq_cny_act_id.nextval'
,p_compute_when=>'P20_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(2084582808736002)
,p_name=>'Hide ISO_CODE and ACT_ID'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_display_when_type=>'ITEM_IS_NULL'
,p_display_when_cond=>'P20_ID'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2084657090736003)
,p_event_id=>wwv_flow_api.id(2084582808736002)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P20_ISO_CODE,P20_ACT_ID'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(2086963581736026)
,p_name=>'OnChange Activity to Klettersteig'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20_ACT_ID'
,p_condition_element=>'P20_ACT_ID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2087051458736027)
,p_event_id=>wwv_flow_api.id(2086963581736026)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P20_DIFFICULTY'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2087569207736032)
,p_event_id=>wwv_flow_api.id(2086963581736026)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P20_MINIMUM_AGE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8148087514510810)
,p_name=>'OnChange Activity to Langlaufen'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20_ACT_ID'
,p_condition_element=>'P20_ACT_ID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8148100187510811)
,p_event_id=>wwv_flow_api.id(8148087514510810)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P20_DIFFICULTY'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8148282289510812)
,p_event_id=>wwv_flow_api.id(8148087514510810)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P20_MINIMUM_AGE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(2087628214736033)
,p_name=>'OnChange Activity to GoKart'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20_ACT_ID'
,p_condition_element=>'P20_ACT_ID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2087778114736034)
,p_event_id=>wwv_flow_api.id(2087628214736033)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P20_MINIMUM_AGE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2087871070736035)
,p_event_id=>wwv_flow_api.id(2087628214736033)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P20_DIFFICULTY'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2068807839584621)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(4105196464032520)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form Aktivit\00E4t Details (Normal)')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2086619892736023)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Additional Info'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  v_cap_id_difficulty  number;',
'  v_cap_id_minimum_age number;',
'begin',
'  select max(cap_id) into v_cap_id_difficulty from country_activity_parameters where ca_id = :P20_ID and param=''DIFFICULTY'';',
'  select max(cap_id) into v_cap_id_minimum_age from country_activity_parameters where ca_id = :P20_ID and param=''MINIMUM_AGE'';',
'  ',
'  apex_debug.info(''v_cap_id_difficulty: ''||v_cap_id_difficulty);',
'  apex_debug.info(''v_cap_id_minimum_age: ''||v_cap_id_minimum_age);',
'',
'  if v_cap_id_difficulty is null then',
'    apex_debug.info(''P20_DIFFICULTY: ''||:P20_DIFFICULTY);',
'    apex_debug.info(''P20_ID: ''||:P20_ID);',
'    if :P20_DIFFICULTY is not null then',
'      apex_debug.info(''Insert Row'');',
'      insert into country_activity_parameters( cap_id, ca_id, param, value)',
'        values(seq_cap_id.nextval,:P20_ID, ''DIFFICULTY'',:P20_DIFFICULTY);',
'    end if;',
'  else',
'    if :P20_DIFFICULTY is not null then',
'      update country_activity_parameters ',
'         set value = :P20_DIFFICULTY',
'         where cap_id = v_cap_id_difficulty;',
'    else',
'      delete from country_activity_parameters where cap_id = v_cap_id_difficulty; ',
'    end if;',
'  end if;',
'',
'  if v_cap_id_minimum_age is null then',
'    if :P20_MINIMUM_AGE is not null then',
'      insert into country_activity_parameters( cap_id, ca_id, param, value)',
'        values(seq_cap_id.nextval,:P20_ID, ''MINIMUM_AGE'',:P20_MINIMUM_AGE);',
'    end if;',
'  else',
'    if :P20_MINIMUM_AGE is not null then',
'      update country_activity_parameters ',
'         set value = :P20_MINIMUM_AGE',
'         where cap_id = v_cap_id_minimum_age;',
'    else',
'      delete from country_activity_parameters where cap_id = v_cap_id_minimum_age; ',
'    end if;',
'  end if;',
'',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(1985398238087833)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2068419833584621)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(4105196464032520)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Aktivit\00E4t Details (Normal)')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2086740264736024)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Additional Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CASE :P20_ACT_ID',
'  when 1 then',
'    select max(value) into :P20_DIFFICULTY from country_activity_parameters where ca_id = :P20_ID and param=''DIFFICULTY'';',
'  when 2 then',
'    select max(value) into :P20_MINIMUM_AGE from country_activity_parameters where ca_id = :P20_ID and param=''MINIMUM_AGE'';',
'  else',
'    null;',
'END CASE;    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P20_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.component_end;
end;
/
