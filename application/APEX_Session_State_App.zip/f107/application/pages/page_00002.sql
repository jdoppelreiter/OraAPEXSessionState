prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(1969123265969110)
,p_name=>'Liste'
,p_alias=>'LISTE'
,p_step_title=>'Liste'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'JOERG'
,p_last_upd_yyyymmddhh24miss=>'20211007182214'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(5257769003960300)
,p_name=>unistr('Aktivit\00E4tenliste')
,p_template=>wwv_flow_api.id(1879546099969039)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--noBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.name as Land',
unistr('     , a.name as Aktivit\00E4t'),
'     , ca.name',
'     , substr(ca.description,0,70)||''...'' as Beschreibung',
'     , ca.link',
'     , ca.active_yn as Aktiv',
'     , cap_d.value as Schwierigkeit',
'     , cap_m.value as Mindestalter',
'  from country_activities ca',
'  join countries c on ca.iso_code = c.iso_code',
'  join activities a on ca.act_id = a.id',
'  left join country_activity_parameters cap_d on ca.id = cap_d.ca_id and cap_d.param = ''DIFFICULTY''',
'  left join country_activity_parameters cap_m on ca.id = cap_m.ca_id and cap_m.param = ''MINIMUM_AGE''',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(1907049990969059)
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5258197592960301)
,p_query_column_id=>1
,p_column_alias=>'LAND'
,p_column_display_sequence=>10
,p_column_heading=>'Land'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5258533067960301)
,p_query_column_id=>2
,p_column_alias=>unistr('AKTIVIT\00C4T')
,p_column_display_sequence=>20
,p_column_heading=>unistr('Aktivit\00E4t')
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5258929727960303)
,p_query_column_id=>3
,p_column_alias=>'NAME'
,p_column_display_sequence=>30
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5259363683960303)
,p_query_column_id=>4
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>40
,p_column_heading=>'Beschreibung'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5259797134960303)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5260173713960303)
,p_query_column_id=>6
,p_column_alias=>'AKTIV'
,p_column_display_sequence=>60
,p_column_heading=>'Aktiv'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5260598860960303)
,p_query_column_id=>7
,p_column_alias=>'SCHWIERIGKEIT'
,p_column_display_sequence=>70
,p_column_heading=>'Schwierigkeit'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5260975306960304)
,p_query_column_id=>8
,p_column_alias=>'MINDESTALTER'
,p_column_display_sequence=>80
,p_column_heading=>'Mindestalter'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5003232627294520)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(5257769003960300)
,p_button_name=>'RESET'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1944600483969082)
,p_button_image_alt=>unistr('Zusatzinfos zur\00FCcksetzen')
,p_button_position=>'REGION_TEMPLATE_EDIT'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5003362091294521)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset'
,p_process_sql_clob=>'delete from country_activity_parameters;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
