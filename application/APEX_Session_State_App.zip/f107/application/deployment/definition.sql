prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 107
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_install(
 p_id=>wwv_flow_api.id(9728791606139393)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop sequence seq_act_id;',
'drop sequence seq_cny_act_id;',
'drop sequence seq_cny_act_img_id;',
'drop sequence seq_cap_id;',
'',
'',
'drop table country_activity_images;',
'drop table country_activity_parameters;',
'drop table country_activities;',
'drop table countries;',
'drop table activity_parameters;',
'drop table activities;',
'',
'drop procedure update_active;',
'drop function has_authorization_yn;'))
);
wwv_flow_api.component_end;
end;
/
