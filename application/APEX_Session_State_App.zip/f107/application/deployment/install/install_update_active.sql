prompt --application/deployment/install/install_update_active
begin
--   Manifest
--     INSTALL: INSTALL-Update Active
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(9729518186209771)
,p_install_id=>wwv_flow_api.id(9728791606139393)
,p_name=>'Update Active'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace PROCEDURE UPDATE_ACTIVE (p_id number) AS ',
'BEGIN',
'  update country_activities',
'     set active_yn = v(''P15_ACTIVE_YN'')',
'     where id = p_id;',
' ',
'END UPDATE_ACTIVE;'))
);
wwv_flow_api.component_end;
end;
/
