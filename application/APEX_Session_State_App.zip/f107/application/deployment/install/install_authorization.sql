prompt --application/deployment/install/install_authorization
begin
--   Manifest
--     INSTALL: INSTALL-Authorization
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(9729435493203785)
,p_install_id=>wwv_flow_api.id(9728791606139393)
,p_name=>'Authorization'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace FUNCTION HAS_AUTHORIZATION_YN (p_authorization_name varchar2)',
'RETURN VARCHAR2 AS ',
'  v_check boolean;',
'BEGIN',
'',
'',
'  v_check := APEX_AUTHORIZATION.IS_AUTHORIZED (p_authorization_name => p_authorization_name);',
'',
'  if v_check then ',
'    return ''Y'';',
'  else',
'    return ''N'';',
'  end if;',
'  ',
'  RETURN ''N'';',
'END HAS_AUTHORIZATION_YN;'))
);
wwv_flow_api.component_end;
end;
/
