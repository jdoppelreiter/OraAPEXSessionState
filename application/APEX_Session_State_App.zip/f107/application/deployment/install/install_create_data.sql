prompt --application/deployment/install/install_create_data
begin
--   Manifest
--     INSTALL: INSTALL-Create Data
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>39012063192019459
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'PLAYGROUND'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(9729114438147723)
,p_install_id=>wwv_flow_api.id(9728791606139393)
,p_name=>'Create Data'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table activities (id number primary key, name varchar2(200) not null, image blob, mime_type varchar2(100));',
'create sequence seq_act_id;',
'',
'create table countries (iso_code char(2) primary key, name varchar2(200) not null);',
'',
'create table country_activities (id number primary key, iso_code char(2) not null ,act_id number not null, name varchar2(200), description clob',
'                               , latitude number, longitude number',
'                               , link varchar2(400)',
'                               , active_yn char(1)',
'                               , constraint fk_cny_act_item_iso foreign key(iso_code) references countries(iso_code),',
'                                 constraint fk_cny_act_item_act foreign key(act_id) references activities(id));',
'create sequence seq_cny_act_id;',
'',
'create table country_activity_images (id number, cny_act_id number, image blob, mime_type varchar2(100),thumbnail_yn varchar2(1),',
'                                      constraint fk_cny_act_item_id foreign key(cny_act_id) references country_activities(id));',
'create sequence seq_cny_act_img_id;',
'',
'create table activity_parameters (code varchar2(50) primary key, act_id number, name varchar2(200),',
'                                  constraint fk_meta_act_id foreign key(act_id) references activities(id));',
'',
'create table country_activity_parameters( cap_id number, ca_id number, param varchar2(50), value varchar2(50),',
'                                          constraint fk_cap_ca_id foreign key(ca_id) references country_activities(id),',
'                                          constraint fk_cap_param foreign key(param) references activity_parameters(code));',
'create sequence seq_cap_id;',
'',
'',
'insert into activities (id, name) values (1, ''Klettersteig'');',
'insert into activities (id, name) values (2, ''Go-Kart'');',
'insert into activities (id, name) values (3, ''Langlaufen'');',
'',
unistr('insert into countries (iso_code,name) values(''AT'',''\00D6sterreich'');'),
'insert into countries (iso_code,name) values(''DE'',''Deutschland'');',
'',
'insert into country_activities(id, iso_code, act_id, name, description, latitude,longitude,link,active_yn)',
' values(1,''AT''',
'       ,1',
'       ,''Attersee-Klettersteig''',
unistr('       ,q''#Das Highlight dieses anspruchsvollen Klettersteigs ist nat\00FCrlich die fantastische Panorama-Aussicht auf den Attersee. Ebenfalls nett: die vielen Stationstafeln mit Sinnspr\00FCchen.'),
'',
unistr('Start/Ziel: Wei\00DFenbach am Attersee'),
'Schwierigkeit: D',
'Charakter: Kombination aus anspruchsvoll-steilen und einfacheren Passagen',
'Gestein: Kalk',
'Beste Jahreszeit: Mai-Oktober',
unistr('Einkehr: Hotel Post in Wei\00DFenbach (unterwegs keine)'),
'Aussicht: Attersee, Mondsee, Salzkammergut-Berge, Tennengebirge u.v.m.#''',
'      , 47.805624899390814',
'      , 13.552915212150685 ',
'      , ''https://www.bergwelten.com/a/7-der-schoensten-klettersteige-in-oesterreich''',
'      , ''Y'');',
'insert into country_activity_images (id, cny_act_id, image, mime_type,thumbnail_yn) ',
'  values(1, 1, null, ''image/jpeg'',''Y'');',
'insert into country_activity_images (id, cny_act_id, image, mime_type,thumbnail_yn) ',
'  values(2, 1, null, ''image/jpeg'',''N'');        ',
'      ',
'      ',
'insert into country_activities(id, iso_code, act_id, name, description, latitude,longitude, link,active_yn)',
' values(2,''AT''',
'       ,1',
'       ,''Hias-Klettersteig''',
unistr('       ,q''#Der Klassiker in der Silberkarklamm auf der S\00FCdseite des Dachsteinmassivs lockt mit guter Erreichbarkeit und einzigartigem Dachstein-Panorama. Gut als Halbtages-Tour geeignet.'),
'',
'Start/Ziel: Ramsau',
'Schwierigkeit: C-D',
unistr('Charakter: Sportlich orientierter Fun-Klettersteig in spektakul\00E4rer Landschaft'),
'Gestein: Kalk',
'Beste Jahreszeit: Mai-Oktober',
unistr('Einkehr: Silberkarh\00FCtte'),
'Aussicht: Silberkarklamm, Schladminger Tauern#''',
'      , 47.4381581433838',
'      , 13.71603170019018',
'      , ''https://www.bergwelten.com/a/7-der-schoensten-klettersteige-in-oesterreich''',
'      , ''Y''); ',
'insert into country_activity_images (id, cny_act_id, image, mime_type,thumbnail_yn) ',
'  values(3, 2, null, ''image/jpeg'',''Y'');',
'insert into country_activity_images (id, cny_act_id, image, mime_type,thumbnail_yn) ',
'  values(4, 2, null, ''image/jpeg'',''N'');    ',
'  ',
'  ',
'insert into country_activities(id, iso_code, act_id, name, description, latitude,longitude, link, active_yn)',
' values(3,''AT''',
'       ,2',
'       ,''Styria Karting''',
unistr('       ,q''#Egal ob Fahrer oder Zuschauer, jung oder junggeblieben, Frauen oder M\00E4nner, bei uns findet jeder seinen pers\00F6nlichen Weg zum Kartsport. '),
'       Die Faszination des Kartfahrens hat schon viele nicht mehr losgelassen.#''',
'      , 47.03435235378784',
'      , 15.412642914323076',
'      , ''http://www.styriakarting.at/''',
'      , ''Y'');    ',
'insert into country_activity_images (id, cny_act_id, image, mime_type,thumbnail_yn) ',
'  values(5, 3, null, ''image/jpeg'',''Y'');',
'insert into country_activity_images (id, cny_act_id, image, mime_type,thumbnail_yn) ',
'  values(6, 3, null, ''image/jpeg'',''N'');         ',
'        ',
'',
'insert into activity_parameters(code, act_id, name)',
'  values(''DIFFICULTY'',1,''Schwierigkeit'');',
'insert into activity_parameters(code, act_id, name)',
'  values(''MINIMUM_AGE'',2,''Mindestalter'');',
'',
''))
);
wwv_flow_api.component_end;
end;
/
